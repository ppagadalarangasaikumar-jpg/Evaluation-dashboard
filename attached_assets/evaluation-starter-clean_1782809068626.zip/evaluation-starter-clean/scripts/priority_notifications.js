import dotenv from 'dotenv';
import { fetchNotifications } from '../src/services/testServerClient.js';
import { Log } from '../src/logging/log.js';

dotenv.config();

const typeWeight = {
  Placement: 3,
  Result: 2,
  Event: 1
};

function notificationScore(notification) {
  const weight = typeWeight[notification.Type] || 0;
  const timestamp = new Date(notification.Timestamp.replace(' ', 'T')).getTime();
  return { weight, timestamp };
}

export function getTopPriorityNotifications(notifications, limit = 10) {
  return [...notifications]
    .sort((a, b) => {
      const scoreA = notificationScore(a);
      const scoreB = notificationScore(b);
      if (scoreB.weight !== scoreA.weight) return scoreB.weight - scoreA.weight;
      return scoreB.timestamp - scoreA.timestamp;
    })
    .slice(0, limit)
    .map((notification, index) => ({
      rank: index + 1,
      id: notification.ID,
      type: notification.Type,
      message: notification.Message,
      timestamp: notification.Timestamp
    }));
}

async function main() {
  await Log('backend', 'info', 'service', 'priority notification script started');

  try {
    const notifications = await fetchNotifications();
    const topNotifications = getTopPriorityNotifications(notifications, 10);

    await Log('backend', 'info', 'service', `priority notification script selected ${topNotifications.length} notifications`);
    process.stdout.write(`${JSON.stringify({ success: true, topNotifications }, null, 2)}\n`);
  } catch (error) {
    await Log('backend', 'error', 'handler', `priority notification script failed: ${error.message}`);
    process.stderr.write(`${JSON.stringify({ success: false, error: error.message }, null, 2)}\n`);
    process.exitCode = 1;
  }
}

main();
