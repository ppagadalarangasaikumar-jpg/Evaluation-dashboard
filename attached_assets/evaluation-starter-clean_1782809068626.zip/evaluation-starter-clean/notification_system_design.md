# Stage 1

## REST API design for campus notifications

### Goals

The notification platform should support creating notifications, listing notifications, filtering unread notifications, marking one notification as read, marking all notifications as read, deleting a notification for a student, and pushing real-time updates when a new notification is available.

### Common headers

```http
Authorization: Bearer <token>
Content-Type: application/json
Accept: application/json
X-Request-ID: <uuid>
```

### Notification object

```json
{
  "id": "uuid",
  "studentId": 1042,
  "type": "Placement",
  "title": "New placement update",
  "message": "Company hiring for backend role",
  "isRead": false,
  "createdAt": "2026-06-30T10:00:00Z",
  "readAt": null
}
```

### Endpoints

#### 1. List notifications

```http
GET /api/students/{studentId}/notifications?status=all&type=Placement&page=1&limit=20
```

Response:

```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "studentId": 1042,
      "type": "Placement",
      "title": "New placement update",
      "message": "Company hiring for backend role",
      "isRead": false,
      "createdAt": "2026-06-30T10:00:00Z",
      "readAt": null
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "hasNext": true
  }
}
```

#### 2. List unread notifications

```http
GET /api/students/{studentId}/notifications/unread?limit=20&cursor=2026-06-30T10:00:00Z
```

Response:

```json
{
  "success": true,
  "unreadCount": 12,
  "data": []
}
```

#### 3. Create notification

```http
POST /api/notifications
```

Request:

```json
{
  "studentIds": [1042, 1043],
  "type": "Placement",
  "title": "Placement drive",
  "message": "A new company is hiring tomorrow."
}
```

Response:

```json
{
  "success": true,
  "notificationBatchId": "uuid",
  "createdCount": 2
}
```

#### 4. Mark one notification as read

```http
PATCH /api/students/{studentId}/notifications/{notificationId}/read
```

Response:

```json
{
  "success": true,
  "message": "Notification marked as read"
}
```

#### 5. Mark all notifications as read

```http
PATCH /api/students/{studentId}/notifications/read-all
```

Response:

```json
{
  "success": true,
  "updatedCount": 12
}
```

#### 6. Delete a notification for a student

```http
DELETE /api/students/{studentId}/notifications/{notificationId}
```

Response:

```json
{
  "success": true,
  "message": "Notification removed"
}
```

### Real-time mechanism

Use Server-Sent Events for simple one-way delivery from server to browser:

```http
GET /api/students/{studentId}/notifications/stream
```

When a new notification is created, the server publishes:

```json
{
  "event": "notification.created",
  "data": {
    "id": "uuid",
    "type": "Placement",
    "title": "Placement drive",
    "message": "A new company is hiring tomorrow.",
    "createdAt": "2026-06-30T10:00:00Z"
  }
}
```

SSE is simple and efficient for notifications because the browser only needs to receive updates. WebSocket can be used later if the product requires two-way real-time communication.

# Stage 2

## Suggested persistent storage

PostgreSQL is the recommended database because the data is structured, read status must be consistent per student, transactions are useful for bulk notification creation, and indexes can support fast filtering by student, read status, type, and creation time.

## Schema

```sql
CREATE TYPE notification_type AS ENUM ('Event', 'Result', 'Placement');

CREATE TABLE students (
  id BIGSERIAL PRIMARY KEY,
  roll_no VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE notifications (
  id UUID PRIMARY KEY,
  notification_type notification_type NOT NULL,
  title VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  created_by VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE student_notifications (
  id UUID PRIMARY KEY,
  student_id BIGINT NOT NULL REFERENCES students(id),
  notification_id UUID NOT NULL REFERENCES notifications(id),
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  read_at TIMESTAMPTZ,
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (student_id, notification_id)
);
```

## Useful indexes

```sql
CREATE INDEX idx_student_notifications_unread_created
ON student_notifications (student_id, is_read, created_at DESC)
WHERE deleted_at IS NULL;

CREATE INDEX idx_notifications_type_created
ON notifications (notification_type, created_at DESC);

CREATE INDEX idx_student_notifications_notification_id
ON student_notifications (notification_id);
```

## Queries based on Stage 1 APIs

List notifications:

```sql
SELECT sn.id, sn.student_id, n.notification_type, n.title, n.message,
       sn.is_read, sn.created_at, sn.read_at
FROM student_notifications sn
JOIN notifications n ON n.id = sn.notification_id
WHERE sn.student_id = $1
  AND sn.deleted_at IS NULL
ORDER BY sn.created_at DESC
LIMIT $2 OFFSET $3;
```

Unread notifications:

```sql
SELECT sn.id, sn.student_id, n.notification_type, n.title, n.message,
       sn.is_read, sn.created_at
FROM student_notifications sn
JOIN notifications n ON n.id = sn.notification_id
WHERE sn.student_id = $1
  AND sn.is_read = FALSE
  AND sn.deleted_at IS NULL
ORDER BY sn.created_at DESC
LIMIT $2;
```

Mark one as read:

```sql
UPDATE student_notifications
SET is_read = TRUE, read_at = NOW()
WHERE student_id = $1
  AND id = $2
  AND deleted_at IS NULL;
```

Mark all as read:

```sql
UPDATE student_notifications
SET is_read = TRUE, read_at = NOW()
WHERE student_id = $1
  AND is_read = FALSE
  AND deleted_at IS NULL;
```

Create notification for many students:

```sql
INSERT INTO notifications (id, notification_type, title, message, created_by)
VALUES ($1, $2, $3, $4, $5);

INSERT INTO student_notifications (id, student_id, notification_id)
SELECT gen_random_uuid(), id, $1
FROM students
WHERE id = ANY($2);
```

## Scaling risks and solutions

As volume grows, full table scans, expensive sorting, heavy writes during bulk notifications, and large old data can slow the system. Use composite indexes for common filters, cursor pagination instead of large offsets, partition old data by month, archive old read notifications, cache unread counts, and move email sending to background workers.

# Stage 3

## Accuracy of the given query

```sql
SELECT * FROM notifications
WHERE studentID = 1042 AND isRead = false
ORDER BY createdAt DESC;
```

This query is only accurate if every notification row belongs to exactly one student and read status is stored in the same table. In a better design, the base `notifications` table stores the notification content, while `student_notifications` stores student-specific read status. In that design, the query is not accurate because `studentID` and `isRead` belong in the mapping table.

## Why it is slow

With 50,000 students and 5,000,000 notifications, the database may scan many rows for `studentID = 1042`, filter unread rows, and then sort by `createdAt`. Without a supporting composite index, the cost can approach O(N log N) for scanned rows because of filtering plus sorting.

## Better query and index

```sql
CREATE INDEX idx_student_unread_created_desc
ON student_notifications (student_id, is_read, created_at DESC)
WHERE deleted_at IS NULL;
```

```sql
SELECT sn.id, n.notification_type, n.title, n.message,
       sn.is_read, sn.created_at
FROM student_notifications sn
JOIN notifications n ON n.id = sn.notification_id
WHERE sn.student_id = 1042
  AND sn.is_read = FALSE
  AND sn.deleted_at IS NULL
ORDER BY sn.created_at DESC
LIMIT 50;
```

Likely cost improves to approximately O(log N + K), where K is the number of rows returned, because the index can directly locate unread notifications for the student in sorted order.

## Should indexes be added on every column?

No. Indexes improve selected read queries, but they also consume storage and slow inserts, updates, and deletes. Adding indexes everywhere is not effective because many indexes will never be used and the write-heavy notification system will become slower. Indexes should match actual query patterns.

## Query to find students who got placement notifications in the last 7 days

```sql
SELECT DISTINCT sn.student_id
FROM student_notifications sn
JOIN notifications n ON n.id = sn.notification_id
WHERE n.notification_type = 'Placement'
  AND sn.created_at >= NOW() - INTERVAL '7 days'
  AND sn.deleted_at IS NULL;
```

# Stage 4

Fetching notifications from the database on every page load for every student creates unnecessary database traffic. The solution should combine caching, pagination, push delivery, and read replicas.

## Recommended strategies

### 1. Cursor pagination

Return only the newest 20 or 50 notifications first. Use `created_at` or a cursor token instead of loading everything.

Tradeoff: The frontend must manage cursors, but database load is much lower.

### 2. Cache unread count and latest notifications

Store unread count and recent notification IDs in Redis or another cache.

Tradeoff: Cache invalidation must be handled carefully when notifications are read or deleted.

### 3. Server-Sent Events for new notifications

Instead of fetching on every page load, push new notifications to active users using SSE.

Tradeoff: Requires connection management, but reduces repeated polling.

### 4. Read replicas

Route read-heavy notification queries to replicas and keep writes on primary database.

Tradeoff: Replicas may have slight delay, so the UI must tolerate eventual consistency for non-critical views.

### 5. Archiving and partitioning

Move old read notifications to archive tables or partitions.

Tradeoff: Historical lookup becomes slightly more complex, but current notification reads stay fast.

# Stage 5

## Problems in the proposed implementation

```text
for each student:
  send_email(student_id, message)
  save_to_db(student_id, message)
```

Problems:

- It is sequential and slow for 50,000 students.
- A failure midway creates inconsistent state.
- There is no retry mechanism for failed email sends.
- There is no idempotency key, so retries may create duplicates.
- Email API latency blocks database writes.
- A single process can overload the database and email provider.

If `send_email` failed for 200 students midway, those failures should be stored as retryable jobs with error details. The system should retry with exponential backoff and mark permanently failed jobs after a maximum retry count.

## Should saving to DB and sending email happen together?

No. In-app notification creation should be persisted first because it is the source of truth. Email sending should be asynchronous through a queue. This design prevents email API failures from blocking in-app notifications.

## Reliable redesigned pseudocode

```text
function notify_all(student_ids, message, type):
  campaign_id = create_notification_campaign(type, message)

  for batch in chunks(student_ids, 1000):
    bulk_insert_student_notifications(campaign_id, batch)

    for student_id in batch:
      enqueue_email_job({
        campaign_id,
        student_id,
        idempotency_key: campaign_id + ':' + student_id
      })

  return campaign_id

worker process_email_jobs:
  job = queue.take()

  if email_already_sent(job.idempotency_key):
    mark_job_success(job)
    return

  try:
    send_email(job.student_id, job.campaign_id)
    save_email_success(job.idempotency_key)
    mark_job_success(job)
  catch error:
    if job.retry_count < MAX_RETRIES:
      requeue_with_backoff(job)
    else:
      mark_job_failed(job, error)
```

# Stage 6

## Priority inbox approach

Priority is calculated using notification type first and recency second:

```text
Placement = 3
Result = 2
Event = 1
```

Sort unread notifications by type weight descending. If two notifications have the same type, sort by timestamp descending. The submitted code file `scripts/priority_notifications.js` fetches notifications from the provided API and prints the top 10.

## Efficient maintenance for continuous new notifications

For a continuous stream of new notifications, maintain a min-heap of size 10. The heap root is the lowest priority item currently in the top 10. When a new notification arrives:

1. If heap size is less than 10, insert it.
2. If the new notification is higher priority than the root, remove the root and insert the new notification.
3. Otherwise ignore it.

This keeps memory usage at O(10) and update cost at O(log 10), which is effectively constant for top 10.
