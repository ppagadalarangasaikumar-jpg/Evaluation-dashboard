# Evaluation Starter Backend

This repository contains:

- Reusable logging middleware
- Vehicle maintenance scheduler backend
- Notification system design document
- Priority notification ranking script

## Setup

```bash
npm install
cp .env.example .env
```

Fill `.env` using the credentials returned from registration.

## Run Backend

```bash
npm start
```

Open API client and test:

```txt
GET http://localhost:3000/health
GET http://localhost:3000/api/vehicle-schedules
```

## Run Priority Notification Script

```bash
npm run priority
```

## Screenshot Requirements

Capture screenshots from your own app/API output:

- API client screenshot for `GET /api/vehicle-schedules`
- Terminal screenshot for `npm run priority`

Commit at milestones:

```bash
git add .
git commit -m "add reusable logging middleware"
git commit -m "add vehicle scheduling backend"
git commit -m "add notification design stages"
git commit -m "add priority notification ranking"
```
