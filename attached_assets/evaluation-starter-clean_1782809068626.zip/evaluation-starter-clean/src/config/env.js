import dotenv from 'dotenv';

dotenv.config();

export const config = {
  port: Number(process.env.PORT || 3000),
  testServerBaseUrl: process.env.TEST_SERVER_BASE_URL || 'http://4.224.186.213/evaluation-service',
  credentials: {
    email: process.env.EMAIL,
    name: process.env.NAME,
    rollNo: process.env.ROLL_NO,
    accessCode: process.env.ACCESS_CODE,
    clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET
  }
};

export function validateRequiredConfig() {
  const missing = [];
  for (const [key, value] of Object.entries(config.credentials)) {
    if (!value || value.startsWith('your_')) missing.push(key);
  }
  return missing;
}
