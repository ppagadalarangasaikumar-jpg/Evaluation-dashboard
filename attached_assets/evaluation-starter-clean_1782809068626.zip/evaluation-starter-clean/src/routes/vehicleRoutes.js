import express from 'express';
import { getVehicleSchedules } from '../controllers/vehicleController.js';
import { Log } from '../logging/log.js';

export const vehicleRouter = express.Router();

vehicleRouter.get('/vehicle-schedules', async (req, res, next) => {
  await Log('backend', 'info', 'route', 'GET /api/vehicle-schedules matched');
  return getVehicleSchedules(req, res, next);
});
