import { Log } from '../logging/log.js';

function normalizeVehicle(vehicle) {
  return {
    taskId: vehicle.TaskID,
    duration: Number(vehicle.Duration),
    impact: Number(vehicle.Impact)
  };
}

export async function chooseBestMaintenanceTasks(vehicles, mechanicHours) {
  const capacity = Number(mechanicHours);
  const tasks = vehicles
    .map(normalizeVehicle)
    .filter((task) => task.taskId && Number.isFinite(task.duration) && Number.isFinite(task.impact) && task.duration > 0);

  await Log('backend', 'debug', 'domain', `running scheduler with ${tasks.length} tasks and ${capacity} mechanic hours`);

  const n = tasks.length;
  const dp = Array.from({ length: n + 1 }, () => Array(capacity + 1).fill(0));

  for (let i = 1; i <= n; i += 1) {
    const { duration, impact } = tasks[i - 1];
    for (let hour = 0; hour <= capacity; hour += 1) {
      dp[i][hour] = dp[i - 1][hour];
      if (duration <= hour) {
        const candidateImpact = impact + dp[i - 1][hour - duration];
        if (candidateImpact > dp[i][hour]) dp[i][hour] = candidateImpact;
      }
    }
  }

  const selectedTasks = [];
  let remainingHours = capacity;

  for (let i = n; i > 0; i -= 1) {
    if (dp[i][remainingHours] !== dp[i - 1][remainingHours]) {
      const task = tasks[i - 1];
      selectedTasks.push(task);
      remainingHours -= task.duration;
    }
  }

  selectedTasks.reverse();
  const usedHours = selectedTasks.reduce((sum, task) => sum + task.duration, 0);
  const totalImpact = selectedTasks.reduce((sum, task) => sum + task.impact, 0);

  await Log('backend', 'info', 'domain', `scheduler selected ${selectedTasks.length} tasks using ${usedHours} hours for impact ${totalImpact}`);

  return {
    mechanicHours: capacity,
    usedHours,
    remainingHours: capacity - usedHours,
    totalImpact,
    selectedTasks
  };
}
