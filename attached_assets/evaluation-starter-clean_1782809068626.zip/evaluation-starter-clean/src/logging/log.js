import { config } from '../config/env.js';
import { getAccessToken } from '../services/authService.js';

const allowedStacks = new Set(['backend', 'frontend']);
const allowedLevels = new Set(['debug', 'info', 'warn', 'error', 'fatal']);
const backendPackages = new Set(['cache', 'controller', 'cron_job', 'db', 'domain', 'handler', 'repository', 'route', 'service']);
const frontendPackages = new Set(['api', 'component', 'hook', 'page', 'state']);
const sharedPackages = new Set(['auth', 'config', 'middleware', 'utils']);

function isPackageAllowed(stack, packageName) {
  if (sharedPackages.has(packageName)) return true;
  if (stack === 'backend') return backendPackages.has(packageName);
  if (stack === 'frontend') return frontendPackages.has(packageName);
  return false;
}

export async function Log(stack, level, packageName, message) {
  const normalized = {
    stack: String(stack || '').toLowerCase(),
    level: String(level || '').toLowerCase(),
    package: String(packageName || '').toLowerCase(),
    message: String(message || '').slice(0, 500)
  };

  if (!allowedStacks.has(normalized.stack)) return false;
  if (!allowedLevels.has(normalized.level)) return false;
  if (!isPackageAllowed(normalized.stack, normalized.package)) return false;

  try {
    const token = await getAccessToken();
    const response = await fetch(`${config.testServerBaseUrl}/logs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(normalized)
    });

    return response.ok;
  } catch {
    return false;
  }
}
