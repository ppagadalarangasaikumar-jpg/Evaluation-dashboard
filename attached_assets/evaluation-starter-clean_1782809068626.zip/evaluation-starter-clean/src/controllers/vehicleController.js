import { fetchDepots, fetchVehicles } from '../services/testServerClient.js';
import { chooseBestMaintenanceTasks } from '../utils/knapsack.js';
import { Log } from '../logging/log.js';

export async function getVehicleSchedules(req, res) {
  const startedAt = Date.now();
  await Log('backend', 'info', 'controller', 'vehicle schedule request received');

  try {
    const [depots, vehicles] = await Promise.all([fetchDepots(), fetchVehicles()]);

    const schedules = [];
    for (const depot of depots) {
      const result = await chooseBestMaintenanceTasks(vehicles, depot.MechanicHours);
      schedules.push({
        depotId: depot.ID,
        ...result
      });
    }

    const responseTimeMs = Date.now() - startedAt;
    await Log('backend', 'info', 'controller', `vehicle schedule request completed in ${responseTimeMs}ms`);

    res.status(200).json({
      success: true,
      responseTimeMs,
      depotCount: depots.length,
      vehicleTaskCount: vehicles.length,
      schedules
    });
  } catch (error) {
    await Log('backend', 'error', 'handler', `vehicle schedule request failed: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Unable to generate vehicle schedules',
      error: error.message
    });
  }
}
