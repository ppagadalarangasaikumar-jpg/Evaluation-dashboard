import express from 'express';
import { config, validateRequiredConfig } from './config/env.js';
import { requestLogger } from './middleware/requestLogger.js';
import { vehicleRouter } from './routes/vehicleRoutes.js';
import { Log } from './logging/log.js';

const app = express();

app.use(express.json());
app.use(requestLogger);

app.get('/health', async (req, res) => {
  await Log('backend', 'info', 'route', 'health check requested');
  res.status(200).json({ success: true, message: 'service is running' });
});

app.use('/api', vehicleRouter);

app.use(async (req, res) => {
  await Log('backend', 'warn', 'route', `${req.method} ${req.originalUrl} route not found`);
  res.status(404).json({ success: false, message: 'route not found' });
});

const missingConfig = validateRequiredConfig();
if (missingConfig.length > 0) {
  process.stderr.write(`Missing .env values: ${missingConfig.join(', ')}\n`);
  process.stderr.write('Fill .env before calling protected APIs. The health route will still run.\n');
}

app.listen(config.port, async () => {
  await Log('backend', 'info', 'config', `server started on port ${config.port}`);
});
