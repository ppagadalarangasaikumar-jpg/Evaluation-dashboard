import { config } from '../config/env.js';

let cachedToken = null;
let tokenExpiryEpochSeconds = 0;

export async function getAccessToken() {
  const nowEpochSeconds = Math.floor(Date.now() / 1000);
  if (cachedToken && tokenExpiryEpochSeconds > nowEpochSeconds + 60) {
    return cachedToken;
  }

  const response = await fetch(`${config.testServerBaseUrl}/auth`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config.credentials)
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Auth failed with status ${response.status}: ${body}`);
  }

  const data = await response.json();
  cachedToken = data.access_token;
  const expiresInSeconds = Number(data.expires_in || 1800);
  tokenExpiryEpochSeconds = nowEpochSeconds + expiresInSeconds;
  return cachedToken;
}
