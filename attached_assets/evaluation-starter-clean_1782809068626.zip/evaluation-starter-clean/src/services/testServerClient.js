import { config } from '../config/env.js';
import { getAccessToken } from './authService.js';
import { Log } from '../logging/log.js';

async function getProtected(path) {
  await Log('backend', 'debug', 'service', `requesting protected resource ${path}`);
  const token = await getAccessToken();

  const response = await fetch(`${config.testServerBaseUrl}${path}`, {
    method: 'GET',
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!response.ok) {
    const body = await response.text();
    await Log('backend', 'error', 'service', `protected resource ${path} failed with status ${response.status}`);
    throw new Error(`GET ${path} failed with status ${response.status}: ${body}`);
  }

  await Log('backend', 'info', 'service', `protected resource ${path} fetched successfully`);
  return response.json();
}

export async function fetchDepots() {
  const data = await getProtected('/depots');
  return data.depots || [];
}

export async function fetchVehicles() {
  const data = await getProtected('/vehicles');
  return data.vehicles || [];
}

export async function fetchNotifications() {
  const data = await getProtected('/notifications');
  return data.notifications || [];
}
