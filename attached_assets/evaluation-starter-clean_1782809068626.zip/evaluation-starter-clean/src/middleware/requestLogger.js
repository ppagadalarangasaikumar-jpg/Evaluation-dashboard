import { Log } from '../logging/log.js';

export function requestLogger(req, res, next) {
  const startedAt = Date.now();
  Log('backend', 'info', 'middleware', `${req.method} ${req.originalUrl} request started`);

  res.on('finish', () => {
    const durationMs = Date.now() - startedAt;
    Log('backend', 'info', 'middleware', `${req.method} ${req.originalUrl} completed with ${res.statusCode} in ${durationMs}ms`);
  });

  next();
}
